BAHÇE SAVUNMASI - ANDROID PROJESİ

Bu proje mevcut HTML oyununuzu Android uygulaması (APK) olarak paketlemek içindir.
Oyun dosyası app/src/main/assets/index.html içine gömülüdür; oyun çevrimdışı çalışacak
şekilde WebView içinde açılır.

APK oluşturma:
1. Bilgisayara Android Studio kurun.
2. Bu ZIP dosyasını açın.
3. Android Studio > Open ile BahceSavunmasi klasörünü seçin.
4. Gradle eşitlemesinin bitmesini bekleyin. Android SDK Platform 35 yüklü değilse
   Android Studio'nun SDK Manager ekranından yükleyin.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) seçeneğini kullanın.
6. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.
7. APK'yı telefona aktarın ve açın. Gerekirse Android ayarlarından bu kaynağa ait
   uygulama yüklemeye izin verin.

Not: Bu çalışma ortamında Android SDK/Gradle kurulu olmadığı için burada derlenmiş,
imzalanmış bir APK üretilmedi. ZIP, Android Studio'da derlenebilir kaynak projedir.
